package com.example.administrator.sharedroute.entity;

public class DialogMenuItem
{
	public String operName;
	public int resId;

	public DialogMenuItem(String operName, int resId)
	{
		this.operName = operName;
		this.resId = resId;
	}
}
